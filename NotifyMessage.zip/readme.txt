﻿NotifyMessage

	Notifying a message in Action center.

	Copyright ©  2015- JeffyTS All rights reserved.

	Installing:
		You can copy NotifyMessage files to any folder.
		NotifyMessage can work any folder. This program never use any registry-key.
		You need .NET Framework 4.5.

	Files:
		NotifyMessage.exe
		readme.txt

	Usage:
		NotifyMessage.exe [opt] "Your message"

	Option:
		/INFO(default) | /WARN | /ERR

	Release & modify
	--- Date --- Ver. -- Modify --
	2015/09/10		Start developping.
	2015/09/12  1.0.0	First release.
	2024/11/30  1.0.0	Change placement to GitHub

